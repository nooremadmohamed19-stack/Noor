import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.example.carracing',
  appName: 'سباق السيارات',
  webDir: 'www'
};

export default config;
