const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// عناصر الواجهة
const scoreText = document.getElementById("scoreText");
const speedText = document.getElementById("speedText");
const gameOverScreen = document.getElementById("game-over-screen");
const finalScoreText = document.getElementById("finalScore");
const highScoreText = document.getElementById("highScore");
const restartBtn = document.getElementById("restartBtn");

// إعدادات اللعبة
let isGameOver = false;
let score = 0;
let highScore = localStorage.getItem("carGameHighScore") || 0;
let baseSpeed = 5;
let currentSpeed = baseSpeed;
let frameCount = 0;

// حالة أزرار التحكم
const keys = { left: false, right: false };

// سيارة اللاعب
const player = {
    width: 42,
    height: 72,
    x: canvas.width / 2 - 21,
    y: canvas.height - 110,
    speed: 6.5,
    color: "#ff4757"
};

// خطوط الطريق
let roadLines = [];
for (let i = 0; i < 6; i++) {
    roadLines.push({ y: i * 110 });
}

// العقبات (السيارات الأخرى)
let obstacles = [];
const obstacleColors = ["#fbc531", "#00a8ff", "#9c88ff", "#4cd137", "#e84118"];

// مؤثرات صوتية بسيطة باستخدام Web Audio API بدون ملفات خارجية
const AudioContextClass = window.AudioContext || window.webkitAudioContext;\nconst audioCtx = AudioContextClass ? new AudioContextClass() : null;
function playBeep(freq, duration) {
    try {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.frequency.value = freq;
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
        osc.stop(audioCtx.currentTime + duration);
    } catch (e) {}
}

// التحكم عبر لوحة المفاتيح
window.addEventListener("keydown", (e) => {
    if (e.key === "ArrowLeft" || e.key.toLowerCase() === "a") keys.left = true;
    if (e.key === "ArrowRight" || e.key.toLowerCase() === "d") keys.right = true;
});

window.addEventListener("keyup", (e) => {
    if (e.key === "ArrowLeft" || e.key.toLowerCase() === "a") keys.left = false;
    if (e.key === "ArrowRight" || e.key.toLowerCase() === "d") keys.right = false;
});

// التحكم عبر اللمس للموبايل
const btnLeft = document.getElementById("btn-left");
const btnRight = document.getElementById("btn-right");

const setupTouch = (btn, key) => {
    btn.addEventListener("touchstart", (e) => { e.preventDefault(); keys[key] = true; });
    btn.addEventListener("touchend", (e) => { e.preventDefault(); keys[key] = false; });
    btn.addEventListener("mousedown", () => keys[key] = true);
    btn.addEventListener("mouseup", () => keys[key] = false);
    btn.addEventListener("mouseleave", () => keys[key] = false);
};

setupTouch(btnLeft, "left");
setupTouch(btnRight, "right");

restartBtn.addEventListener("click", restartGame);

// رسم السيارة وتفاصيلها
function drawCar(x, y, width, height, color) {
    ctx.save();
    
    // الهيكل
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.roundRect(x, y, width, height, 8);
    ctx.fill();

    // الزجاج الأمامي والخلفي
    ctx.fillStyle = "#1e272e";
    ctx.fillRect(x + 5, y + 14, width - 10, 12);
    ctx.fillRect(x + 6, y + height - 20, width - 12, 8);

    // الكفرات
    ctx.fillStyle = "#111";
    ctx.fillRect(x - 3, y + 10, 4, 12);
    ctx.fillRect(x + width - 1, y + 10, 4, 12);
    ctx.fillRect(x - 3, y + height - 22, 4, 12);
    ctx.fillRect(x + width - 1, y + height - 22, 4, 12);

    // المصابيح الأمامية
    ctx.fillStyle = "#f5f6fa";
    ctx.fillRect(x + 4, y + 2, 7, 4);
    ctx.fillRect(x + width - 11, y + 2, 7, 4);

    ctx.restore();
}

// توليد عقبة جديدة
function spawnObstacle() {
    const width = 42;
    const height = 72;
    const lanes = [25, 110, 195, 280];
    const lane = lanes[Math.floor(Math.random() * lanes.length)];
    const color = obstacleColors[Math.floor(Math.random() * obstacleColors.length)];

    obstacles.push({
        x: lane,
        y: -height,
        width: width,
        height: height,
        color: color
    });
}

// التحقق من التصادم
function checkCollision(r1, r2) {
    const padding = 4; // هامش أمان لتكون اللعبة أكثر دقة
    return (
        r1.x + padding < r2.x + r2.width - padding &&
        r1.x + r1.width - padding > r2.x + padding &&
        r1.y + padding < r2.y + r2.height - padding &&
        r1.y + r1.height - padding > r2.y + padding
    );
}

// تحديث إحداثيات اللعبة
function update() {
    if (isGameOver) return;

    frameCount++;

    // حركة سيارة اللاعب مع منعها من الخروج عن الطريق
    if (keys.left && player.x > 15) {
        player.x -= player.speed;
    }
    if (keys.right && player.x < canvas.width - player.width - 15) {
        player.x += player.speed;
    }

    // حركة خطوط الطريق
    roadLines.forEach(line => {
        line.y += currentSpeed;
        if (line.y > canvas.height) line.y = -60;
    });

    // توليد العقبات بفترات تتناسب مع السرعة
    const spawnRate = Math.max(45, Math.floor(100 - currentSpeed * 4));
    if (frameCount % spawnRate === 0) {
        spawnObstacle();
    }

    // تحديث العقبات
    for (let i = 0; i < obstacles.length; i++) {
        let obs = obstacles[i];
        obs.y += currentSpeed;

        // التحقق من الحادث
        if (checkCollision(player, obs)) {
            gameOver();
            return;
        }

        // تخطي العقبة بنجاح
        if (obs.y > canvas.height) {
            obstacles.splice(i, 1);
            i--;
            score += 10;
            scoreText.innerText = score;
            playBeep(400, 0.05);

            // زيادة تدريجية في السرعة
            if (score % 50 === 0 && currentSpeed < 14) {
                currentSpeed += 0.5;
                speedText.innerText = (currentSpeed / baseSpeed).toFixed(1);
            }
        }
    }
}

// رسم المشهد
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // الطريق
    ctx.fillStyle = "#2f3542";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // الحواف الجانبية للطريق
    ctx.fillStyle = "#e84118";
    ctx.fillRect(0, 0, 10, canvas.height);
    ctx.fillRect(canvas.width - 10, 0, 10, canvas.height);

    // مسارات الطريق
    ctx.fillStyle = "#f5f6fa";
    roadLines.forEach(line => {
        ctx.fillRect(canvas.width / 3, line.y, 5, 45);
        ctx.fillRect((canvas.width / 3) * 2, line.y, 5, 45);
    });

    // رسم اللاعب والعقبات
    drawCar(player.x, player.y, player.width, player.height, player.color);
    obstacles.forEach(obs => drawCar(obs.x, obs.y, obs.width, obs.height, obs.color));
}

// دورة اللعبة المستمرة
function gameLoop() {
    update();
    draw();
    if (!isGameOver) {
        requestAnimationFrame(gameLoop);
    }
}

function gameOver() {
    isGameOver = true;
    playBeep(120, 0.4); // صوت الاصطدام

    if (score > highScore) {
        highScore = score;
        localStorage.setItem("carGameHighScore", highScore);
    }

    finalScoreText.innerText = score;
    highScoreText.innerText = highScore;
    gameOverScreen.style.display = "flex";
}

function restartGame() {
    obstacles = [];
    score = 0;
    currentSpeed = baseSpeed;
    frameCount = 0;
    player.x = canvas.width / 2 - player.width / 2;
    isGameOver = false;

    scoreText.innerText = "0";
    speedText.innerText = "1.0";
    gameOverScreen.style.display = "none";

    requestAnimationFrame(gameLoop);
}

// بدء اللعبة
requestAnimationFrame(gameLoop);